/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;


import appboot.LARVABoot;
import static crypto.Keygen.getHexaKey;

/**
 *
 * @author ravolk
 */
public class main {
    
    public static void main(String[] args) {
//        bootJADE();
        //bootLARVA();
        LARVABoot boot = new LARVABoot();
        
        // Boot( ) creates a container for future agents
        // Should JADE be running in local
//        boot.Boot("localhost", 1099);
//        boot.Boot("localhost", 1099);
        // Otherwise our server always run JADE  ;-)
         boot.Boot("isg2.ugr.es", 1099);  // Our server is isg2
        // boot.Boot("150.214.190.126", 1099);  // Should there be problems with DNS
        
        // Create the agent and executes it
//        boot.launchAgent("Smith-"+getHexaKey(4), AgentLARVA.class);
        boot.launchAgent("TS-"+getHexaKey(4), BASICAGENT_TS.class);
        
        // Closes the container and exits
        boot.WaitToShutDown();
    }
    
}
