/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

import Environment.Environment;
import agents.BB1F;
import agents.DEST;
import agents.DroidShip;
import agents.LARVAFirstAgent;
import agents.MTT;
import agents.YV;
import ai.Choice;
import ai.DecisionSet;
import ai.Plan;
import geometry.Point3D;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import static java.util.stream.Collectors.joining;
import tools.emojis;
import world.Perceptor;

public class COMPLEXAGENT_TS extends BASICAGENT_TS {

    ACLMessage controller;

    String ssd, MTT_receiver;

    @Override
    public void setup() {
        super.setup();
        sessionAlias = this.inputLine("Write session Alias");
        this.defSessionAlias(sessionAlias);
    }

    public Status MySelectMission() {
        return SelectMission();
    }

    @Override
    public Status SelectMission() {
        controller = LARVAblockingReceive();

        if (controller.getPerformative() == ACLMessage.REQUEST) {
            ssd = controller.getSender().getLocalName();
            E.makeCurrentMission(controller.getContent());
            this.MyReadPerceptions();
            resetAutoNAV();
            E.resetCourse();
            return Status.SOLVEPROBLEM;
        } else if (controller.getPerformative() == ACLMessage.CANCEL) {
            return Status.CHECKOUT;
        } else {
            return Status.CHECKOUT;
        }
    }

    @Override
    public void Execute() {
        Info("Status: " + myStatus.name());
        switch (myStatus) {
            case START:
                myStatus = Status.CHECKIN;
                break;
            case CHECKIN:
                // The execution of a state (as a method) returns
                // the next state
                myStatus = MyCheckin();
                break;
            case SELECTMISSION:
                myStatus = MySelectMission();
                break;
            case JOINSESSION: // This is new wrt HelloWorld
                myStatus = MyJoinSession();
                break;
            case SOLVEPROBLEM:
                myStatus = MySolveProblem();
                break;
            case MOVECITY:
                myStatus = MyMoveCity();
                break;

            case CHECKOUT:
                myStatus = MyCheckout();
                break;
            case EXIT:
            default:
                doExit();
                break;
        }
    }

    @Override
    public Status MyCheckin() {
        Info("Loading passport and checking-in to LARVA");
        // It loads the passport specified in the GUI, but otherwise
        // it might load any other passpor manually (uncomment)
        //this.loadMyPassport("./config/MARIA_AGUADO_MARTINEZ.passport");

        // If checkin works, then continue, else exti
        if (!doLARVACheckin()) {
            Error("Unable to checkin");
            return Status.EXIT;
        }
        return Status.JOINSESSION;
    }

    @Override
    public Status MyJoinSession() {

        
        //BUSCAR EN EL DF EL SESSION MANAGER Y EL SSD
        ArrayList<String> sm_list = this.DFGetAllProvidersOf("SESSION MANAGER");
        int i = 0;
        sessionManager = sm_list.get(i);

        while (!this.DFHasService(sessionManager, sessionAlias)) {
            i++;
            sessionManager = sm_list.get(i);
        }
        ArrayList<String> servicios = this.DFGetAllServicesProvidedBy(sessionManager);
        System.out.println(String.join(" ", servicios));
        for (int j = 0; j < servicios.size(); j++) {
            if (servicios.get(j).startsWith("SESSION::")) {
                sessionKey = servicios.get(j);
            }
            System.out.println(sessionKey);

        }

        Info("Querying CITIES");
        outbox = new ACLMessage();
        outbox.setSender(this.getAID());
        outbox.addReceiver(new AID(sessionManager, AID.ISLOCALNAME));
        outbox.setContent("Query cities session " + sessionKey);
        outbox.setPerformative(ACLMessage.QUERY_REF);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = LARVAblockingReceive();
        this.getEnvironment().setExternalPerceptions(session.getContent());
        String[] ciudades = this.getEnvironment().getCityList();

        String ciudadElegida = this.inputSelect("Please choose a city", ciudades, "");
        Point3D posCiudad = this.getEnvironment().getCityPosition(ciudadElegida);

        this.resetAutoNAV();
        // Register in the DF
        this.DFAddMyServices(new String[]{"TYPE TS", "TEAM " + sessionAlias});
        outbox = session.createReply();

        //outbox.setContent("Request join session " + sessionKey + " at " + posCiudad.getXInt() + " " + posCiudad.getYInt());
        outbox.setContent("Request join session " + sessionKey + " in " + ciudadElegida);
        outbox.setPerformative(ACLMessage.REQUEST);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = this.LARVAblockingReceive();

        if (!session.getContent().startsWith("Confirm")) {
            Error("Could not join session " + sessionKey + " due to " + session.getContent());
            return Status.CHECKOUT;
        }

        outbox = session.createReply();
        outbox.setContent("Query missions session " + sessionKey);
        outbox.setPerformative(ACLMessage.QUERY_REF);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = this.LARVAblockingReceive();
        this.getEnvironment().setExternalPerceptions(session.getContent());

        // Immediately afterwards, read the first perceptions
        this.MyReadPerceptions();

        return Status.SELECTMISSION;
    }

    @Override
    public Status MyMoveCity() {
        int altura = E.getGround() / 5;
        Info("altura= " + altura);
        if(E.getEnergy()<energybound){
            int contador = 0;
            for(int i=0; i<altura; i++){
                if (contador >= 5){
                    contador = 0;
                    this.MyExecuteAction("RIGHT");
                    this.MyExecuteAction("LEFT");
                    
                }
                this.MyExecuteAction("DOWN");
                contador+=1;
            }
        this.MyReadPerceptions();
        AskForRecharge();
        }
        behaviour = AgPlan(E, A);
        if (behaviour == null || behaviour.isEmpty()) {

            String[] splitGoal = CurrentGoal.split(" ");
            Info("Current city : " + this.getEnvironment().getCurrentCity() + " Target city : " + cityGoal);
            if (getEnvironment().getCurrentCity().equals(cityGoal)) {
                Info("Resolved goal : " + CurrentGoal);
                E.setNextGoal();
                doSendCompleteGoal(CurrentGoal);
                return Status.SOLVEPROBLEM;

            } else {
                Alert("Found no plan to execute");
                return Status.SELECTMISSION;
            }

        } else {// Execute
            Info("Found plan: " + behaviour.toString());
            while (!behaviour.isEmpty()) {
                a = behaviour.get(0);
                behaviour.remove(0);
                Info("Excuting " + a);
                if (a.getName().equals("RECHARGE")) {
                    AskForRecharge();
                } else {
                    this.MyExecuteAction(a.getName());
                    /*Info("\n---------------------------------------------------\n"
                        + "executing:" + a.getName() + " :\n " + this.easyPrintPerceptions(E, A)
                        + "\nPlan: " + behaviour.toString() + "\n");*/
                }

                if (!Ve(E)) {
                    this.Error("The agent is not alive: " + E.getStatus());
                    return Status.SELECTMISSION;
                }
            }
            this.MyReadPerceptions();
            return Status.MOVECITY;
        }
    }

    @Override
    public Status MySolveProblem() {
        // Analizar objetivo
        //System.out.print(A.toString());
        //Info(this.easyPrintPerceptions(E, A));
        CurrentGoal = E.getCurrentGoal();

        Info("The goal is " + CurrentGoal);
        
        if (E.getCurrentMission().isOver()) {
            Info("The problem is over");
            this.Message("The current mission has been solved");
            return doSendCompleteMission();
            
        }

        if (CurrentGoal.startsWith("MOVEIN")) {
            String[] splitGoal = CurrentGoal.split(" ");
            cityGoal = splitGoal[1];
            for (int i = 2; i < splitGoal.length; i++) {
                cityGoal += " " + splitGoal[i];
            }
            if (getEnvironment().getCurrentCity().equals(cityGoal)) {
                Info("Resolved goal : " + CurrentGoal);
                E.setNextGoal();
                Info("Estoy dentro del if");
                doSendCompleteGoal(CurrentGoal);
           
                return Status.SOLVEPROBLEM;
            }
            
            resetAutoNAV();
            outbox = session.createReply();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);

            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            return Status.MOVECITY;

        } else if (CurrentGoal.startsWith("LIST")) {
            String[] splitGoal = CurrentGoal.split(" ");
            doQueryPeople(splitGoal[1], true);
            Info("Resolved goal : " + CurrentGoal);
            doSendCompleteGoal(CurrentGoal);
            E.setNextGoal();
            return Status.SOLVEPROBLEM;
        } else if (CurrentGoal.startsWith("REPORT")) {

            String[] splitGoal = CurrentGoal.split(" ");
            doSendReport(splitGoal[1]);
            doSendCompleteGoal(CurrentGoal);
            E.setNextGoal();
            return Status.SOLVEPROBLEM;
            
        } else if (CurrentGoal.startsWith("CAPTURE")) {
            String[] splitGoal = CurrentGoal.split(" ");
            cityGoal = splitGoal[3];
            for (int i = 4; i < splitGoal.length; i++) {
                cityGoal += " " + splitGoal[i];
            }

            //If we have arrived to the city we keep on with the capture
            if (getEnvironment().getCurrentCity().equals(cityGoal)) {
                Info("We are in city: " + E.getCurrentCity());
                doCapture(splitGoal[2], Integer.parseInt(splitGoal[1]));
                
                E.setNextGoal();
                return Status.SOLVEPROBLEM;
            }
            resetAutoNAV();
            outbox = session.createReply();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);

            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            return Status.MOVECITY;

        } else if (CurrentGoal.startsWith("REQUEST MTT")) {

            String[] splitGoal = CurrentGoal.split(" ");
            cityGoal = splitGoal[2];
            for (int i = 3; i < splitGoal.length; i++) {
                cityGoal += " " + splitGoal[i];
            }

            //If we have arrived to the city we keep on with the capture
            if (getEnvironment().getCurrentCity().equals(cityGoal)) {
                Info("We are in city: " + E.getCurrentCity());
                doAskBackup(splitGoal[1]);
                doSendCompleteGoal(CurrentGoal);
                E.setNextGoal();
                return Status.SOLVEPROBLEM;
            }
            resetAutoNAV();
            outbox = session.createReply();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);

            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            return Status.MOVECITY;

        } else if (CurrentGoal.startsWith("CANCEL MTT")) {
            String[] splitGoal = CurrentGoal.split(" ");
            cityGoal = splitGoal[2];
            for (int i = 3; i < splitGoal.length; i++) {
                cityGoal += " " + splitGoal[i];
            }

            //If we have arrived to the city we keep on with the capture
            if (getEnvironment().getCurrentCity().equals(cityGoal)) {
                Info("We are in city: " + E.getCurrentCity());
                doCancelBackup(splitGoal[2]);
                doSendCompleteGoal(CurrentGoal);
                E.setNextGoal();
                
                return Status.SOLVEPROBLEM;
            }
            resetAutoNAV();
            outbox = session.createReply();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);

            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            return Status.MOVECITY;

        } else if (CurrentGoal.startsWith("MOVEBY")) {
            String[] splitGoal = CurrentGoal.split(" ");

            //If we have arrived to the city we keep on with the capture
            String transponder = doAskTransponder(splitGoal[1]);

            String[] splitTransponder = transponder.split("/");
            Info("Localizacion1 " + splitTransponder[3]);

            String DESTLocation = (splitTransponder[3].split(" "))[2];
            for (int i = 3; i < splitTransponder[3].split(" ").length; i++) {
                DESTLocation += " " + (splitTransponder[3].split(" "))[i];
            }

            Info("Locaclizacion2 " + DESTLocation);
            cityGoal = DESTLocation;
            if (getEnvironment().getCurrentCity().equals(cityGoal)) {
                Info("Resolved goal : " + CurrentGoal);
                doSendCompleteGoal(CurrentGoal);
                E.setNextGoal();
                return Status.SOLVEPROBLEM;
            }
            resetAutoNAV();
            outbox = session.createReply();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);

            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            return Status.MOVECITY;

        } else if (CurrentGoal.startsWith("TRANSFER")) {
            String[] splitGoal = CurrentGoal.split(" ");
            doTransfer();
            Info("Resolved goal : " + CurrentGoal);
            E.setNextGoal();
            
            return Status.SOLVEPROBLEM;

        }
        return Status.SELECTMISSION;
    }

    
    public void doSendCompleteGoal(String goal){
        //Le mandamos un mensaje al SSD con el objetivo que acabamos de terminar
        outbox = controller.createReply();

        Info("Enviando al ssd: " + ssd+ "// GOAL: "+goal+"completado");
        if (goal.startsWith("TRANSFER")){
            outbox.setContent("TRANSFER");
        }
        else
            outbox.setContent(goal);
        outbox.setPerformative(ACLMessage.INFORM_REF);
        outbox.setConversationId(sessionAlias);

        this.LARVAsend(outbox);
    }
    
    public Status doSendCompleteMission(){
        outbox = controller.createReply();

        Info("Enviando al ssd: " + ssd+ "// Misión completada");
        
        outbox.setContent(E.getCurrentMission().getName());
        outbox.setPerformative(ACLMessage.INFORM);
        //outbox.setConversationId(sessionAlias);
        
        this.LARVAsend(outbox);
        
         //controller = LARVAblockingReceive();
            return Status.SELECTMISSION;
            
      
            
        
    }
    
    public void doAskBackup(String type) {
        Info("Looking for agents: MTT");

        //DroidShip.Debug();

        ArrayList<String> receiver_list = this.DFGetAllProvidersOf("TYPE MTT");
        Info("Numero de MTTs: "+receiver_list.size());
        int i = 0;
        MTT_receiver = receiver_list.get(i);
        boolean backup = false;
        boolean comprobado = false;
        while (!backup) {

            do {

                //We look for the next one in the list we already have
                while (!this.DFHasService(MTT_receiver, sessionKey) || comprobado) {
                    i++;
                    Info("Cuanto vale i: "+i);
                    //If we finished the list, we start again
                    if (i % receiver_list.size() == 0) {
                        Info("Looking for providers again....");
                        receiver_list = this.DFGetAllProvidersOf("TYPE MTT");
                        i = 0;    
                    }
                    MTT_receiver = receiver_list.get(i);
                    comprobado = false;
                }
                LARVAwait(5000);
                Info("Found agent MTT: " + MTT_receiver);

                outbox = new ACLMessage();
                outbox.setSender(getAID());
                outbox.setReplyWith("mtt_msg" + Integer.toString(i));
                outbox.addReceiver(new AID(MTT_receiver, AID.ISLOCALNAME));
                Info("Receiver" + MTT_receiver);
                outbox.setContent("BACKUP");
                outbox.setPerformative(ACLMessage.REQUEST);
                //outbox.setConversationId(sessionKey);
                outbox.setProtocol("DROIDSHIP");
                this.LARVAsend(outbox);

                Info("REQUEST BACKUP sent: to " + MTT_receiver);
                //If the message is refuse, we try again, else, we continue with the recharge
                droidMTT = LARVAblockingReceive();
                Info(MTT_receiver + " says: " + droidMTT.getContent());

                content = droidMTT.getContent();
                contentTokens = content.split(" ");
                
                //If the droidship accepts, it sends a request for transponder, and then an agree message
                comprobado = true;
            } while (droidMTT.getPerformative() != ACLMessage.AGREE);

            Info("Request backup accepted by droidship " + MTT_receiver);

            //droidship is going to send us two transponder requests, so we just wait until the inform message
            droidMTT = LARVAblockingReceive();
            Info(MTT_receiver + " says: " + droidMTT.getContent());
            content = droidMTT.getContent();
            contentTokens = content.split(" ");
            if (!contentTokens[0].toUpperCase().equals("FAILURE")) {
                Info("MTT is coming to the city");
                backup = true;
            }
            //If there has been a failure in some of the messages, the process starts all over again

        }
    }

    public void doCancelBackup(String type) {

        //Liberamos al mtt
        outbox = new ACLMessage();
        outbox.setSender(getAID());
        outbox.setReplyWith("mtt_msg");
        outbox.addReceiver(new AID(MTT_receiver, AID.ISLOCALNAME));
        outbox.setContent("CANCEL");
        outbox.setPerformative(ACLMessage.CANCEL);
        outbox.setConversationId(sessionKey);
        outbox.setProtocol("DROIDSHIP");
        this.LARVAsend(outbox);

        // droidMTT = LARVAblockingReceive();
        //Info(receiver + " says: " + droidMTT.getContent());
    }

    @Override
    public void doTransfer() {

        doAskTransponder();
        int n = capturedPeople.size();

        for (int j = 0; j < n; j++) {

            outbox = droidDEST.createReply();
            outbox.setContent("TRANSFER " + capturedPeople.get(j));
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);
            outbox.setProtocol("DROIDSHIP");
            this.LARVAsend(outbox);

            droidDEST = LARVAblockingReceive();

            if (droidDEST.getPerformative() == ACLMessage.FAILURE) {
                Info("Transfer " + "failed: " + droidDEST.getContent());
            } else {
                Info("Transfer " + "correct ");
                doSendCompleteGoal(CurrentGoal);
            }
        }

        Info("Finished transfering people");

    }
    
    @Override
    public void doCapture(String type, int n){
        
        boolean enCiudad = false;
        while (!enCiudad){
            //PRIMERO comprobamos que el MTT está 
            outbox =droidMTT.createReply();
            outbox.setContent("TRANSPONDER");
            outbox.setPerformative(ACLMessage.QUERY_REF);
            //outbox.setConversationId(sessionKey);
            outbox.setProtocol("DROIDSHIP");
            this.LARVAsend(outbox);

            droidMTT = LARVAblockingReceive();
            Info(MTT_receiver + " says: " + droidMTT.getContent());

            content = droidMTT.getContent();
            Info("Content transponder mtt= " + content);
            String[] splitTransponder = content.split("/");
            String MTTLocation = (splitTransponder[3].split(" "))[2];
            String status=(splitTransponder[3].split(" "))[1];
            for (int i = 3; i < splitTransponder[3].split(" ").length; i++) {
                MTTLocation += " " + (splitTransponder[3].split(" "))[i];
            }

            Info("Locaclizacion2 mtt " + MTTLocation);
            if (status.equals("GROUNDED") && getEnvironment().getCurrentCity().equals(MTTLocation)) {
                enCiudad=true;
            }
            else{
                LARVAwait(5000);

            }
        }
        
        
        //Se encarga de pedirle al session manager que capture 
        doQueryPeople(type, false);
        String[] names = E.getPeople();
        for (int i =0;  i < n; i ++){
            outbox = session.createReply();
            outbox.setContent("Request capture " + names[i] + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);
            outbox.setReplyWith("capture_"+Integer.toString(i));
            
            this.LARVAsend(outbox);

            session = LARVAblockingReceive();
            
            
            if (session.getPerformative()==ACLMessage.FAILURE) {
                Info("Capture "+ names[i]+ "failed: " + session.getContent());
            }
            else{
                Info("Capture "+ names[i]+ "correct ");
                capturedPeople.add(names[i]);
                doSendCompleteGoal(CurrentGoal);
            }
        }
        Info("Finished capturing people");
    }

    public String doAskTransponder() {
        Info("Looking for agents: DEST");

        //DroidShip.Debug();

        ArrayList<String> receiver_list = this.DFGetAllProvidersOf("TYPE DEST");
        int i = 0;
        String receiver = receiver_list.get(i);

        //We look for the next one in the list we already have
        while (!this.DFHasService(receiver, sessionKey)) {
            i++;
            //If we finished the list, we start again
            if (i % receiver_list.size() == 0) {
                Info("Looking for providers again....");
                receiver_list = this.DFGetAllProvidersOf("TYPE DEST");

            }
            receiver = receiver_list.get(i % receiver_list.size());
        }

        DESTship = receiver;

        Info("Found agent DEST: " + receiver);

        outbox = new ACLMessage();
        outbox.setSender(getAID());
        outbox.setReplyWith("dest_msg");
        outbox.addReceiver(new AID(receiver, AID.ISLOCALNAME));
        outbox.setContent("TRANSPONDER");
        outbox.setPerformative(ACLMessage.QUERY_REF);
        outbox.setConversationId(sessionKey);
        outbox.setProtocol("DROIDSHIP");
        this.LARVAsend(outbox);

        droidDEST = LARVAblockingReceive();
        Info(receiver + " says: " + droidDEST.getContent());

        content = droidDEST.getContent();
        Info("Content doasktransponder = " + content);
        return content;

    }

}
