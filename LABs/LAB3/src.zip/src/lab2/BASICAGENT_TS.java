/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

import Environment.Environment;
import agents.BB1F;
import agents.DEST;
import agents.DroidShip;
import agents.LARVAFirstAgent;
import agents.MTT;
import agents.YV;
import ai.Choice;
import ai.DecisionSet;
import ai.Plan;
import geometry.Point3D;
import jade.core.AID;
import jade.lang.acl.ACLMessage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import static java.util.stream.Collectors.joining;
import tools.emojis;
import world.Perceptor;


public class BASICAGENT_TS extends LARVAFirstAgent {

    Status myStatus;    // The current state
    String service = "PMANAGER", // How to find Problem Manager in DF
            problem, // Name of the problem to solve
            problemManager = "", // Name of the Problem Manager, when it woudl be knwon
            sessionManager, // Same for the Session Manager
            content, // Content of messages
            DESTship,
            sessionKey, preplan="", action="", cityGoal=""; // The key for each work session 
    ACLMessage open, session, droidDEST, droidBB1F, droidMTT; // Backup of relevant messages
    String[] contentTokens, plan, problems={
            "Wobani.Apr1",
            "Wobani.Not1",
            "Wobani.Sob1",
            "Wobani.Hon1",
            

        };//=new String[]{"MOVE", "RIGHT", "RIGHT", "MOVE", "MOVE", "MOVE", "EXIT"}; // To parse the content
    
    protected Map<String, Map<String, String>> reports = new HashMap<String, Map<String, String>>();
    int iplan =0, myEnergy=0, energybound=80;
    protected boolean showPerceptions = false, useAlias = false;
    protected String whichWall, nextWhichwall;
    protected double distance, nextdistance;
    protected Point3D point, nextPoint;
    protected Point3D[] ruta;
    protected Point3D objetivo;
    protected Plan behaviour = null;
    protected Environment Ei, Ef;
    protected Choice a;
    protected String CurrentGoal;
    protected ArrayList<String> capturedPeople = new ArrayList<>();

    

// This is the firs method executed by any agent, right before its creation
    @Override
    public void setup() {
       this.enableDeepLARVAMonitoring();
       showPerceptions =false;
        // The constructor of the superclass
        super.setup();
        this.deactivateSequenceDiagrams();
        logger.onEcho();
        // ACtivates a tabular-like output of agents
        logger.onTabular();
        // First status of execution
        myStatus = Status.START;


        this.setupEnvironment();
        
        A = new DecisionSet();
        A.
                addChoice(new Choice("DOWN")).
                addChoice(new Choice("UP")).
                addChoice(new Choice("MOVE")).
                addChoice(new Choice("LEFT")).
                addChoice(new Choice("RIGHT")).
                addChoice(new Choice("RECHARGE"));
        
    }

    // Main execution body andter the executoin of setup( ). It executes continuously until 
    // the exact execution of doExit() after which it executes
    // takeDown()
    @Override
    public void Execute() {
        Info("Status: " + myStatus.name());
        switch (myStatus) {
            case START:
                myStatus = Status.CHECKIN;
                break;
            case CHECKIN:
                // The execution of a state (as a method) returns
                // the next state
                myStatus = MyCheckin();
                break;
            case OPENPROBLEM:
                myStatus = MyOpenProblem();
                break;
            case JOINSESSION: // This is new wrt HelloWorld
                myStatus = MyJoinSession();
                break;
            case SOLVEPROBLEM:
                myStatus = MySolveProblem();
                break;
            case MOVECITY:
                myStatus = MyMoveCity();
                break;
            case CLOSEPROBLEM:
                myStatus = MyCloseProblem();
                break;
            case CHECKOUT:
                myStatus = MyCheckout();
                break;
            case EXIT:
            default:
                doExit();
                break;
        }
    }

    // It only executes when the agent dies programmatically, that is, under control
    @Override
    public void takeDown() {
        Info("Taking down...");
        // Save the Sequence Diagram
        //this.saveSequenceDiagram("./" + getLocalName() + ".seqd");
        super.takeDown();
    }

    // It loads the passport selected in the GUI and send it to the Identity manager
    public Status MyCheckin() {
        Info("Loading passport and checking-in to LARVA");
        // It loads the passport specified in the GUI, but otherwise
        // it might load any other passpor manually (uncomment)
        //this.loadMyPassport("./config/MARIA_AGUADO_MARTINEZ.passport");
        
        // If checkin works, then continue, else exti
        if (!doLARVACheckin()) {
            Error("Unable to checkin");
            return Status.EXIT;
        }
        return Status.OPENPROBLEM;
    }

    // Says good by to the Identity Manager and leaves LARVA
    public Status MyCheckout() {
        this.doLARVACheckout();
        return Status.EXIT;
    }

    public Status MyOpenProblem() {
        // Look i the DF who is in charge of service PMANAGER
        if (this.DFGetAllProvidersOf(service).isEmpty()) {
            Error("Service PMANAGER is down");
            return Status.CHECKOUT;
        }
        problemManager = this.DFGetAllProvidersOf(service).get(0);
        Info("Found problem manager " + problemManager);
        
        problem = this.inputSelect("Please select problem to solve", problems, problem);
        if (problem == null) {
            return Status.CHECKOUT;
        }
        // Send it a message to open a problem instance
        this.outbox = new ACLMessage();
        outbox.setSender(getAID());
        //outbox.setPerformative(ACLMessage.REQUEST);
        outbox.addReceiver(new AID(problemManager, AID.ISLOCALNAME));
        outbox.setContent("Request open " + problem + " alias " + sessionAlias);
        outbox.setPerformative(ACLMessage.REQUEST);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        Info("Request opening problem " + problem + " to " + problemManager);
        
        // There will be arriving two messages, one coming from the
        // Problem Manager and the other from the brand new Session Manager
        open = LARVAblockingReceive();
        Info(problemManager + " says: " + open.getContent());
        content = open.getContent();
        contentTokens = content.split(" ");
        if (contentTokens[0].toUpperCase().equals("AGREE")) {
            sessionKey = contentTokens[4];
            session = LARVAblockingReceive();
            sessionManager = session.getSender().getLocalName();
            Info(sessionManager + " says: " + session.getContent());
            return Status.JOINSESSION;
        } else {
            Error(content);
            return Status.CHECKOUT;
        }
    }

/** SOLVE PROBLEM
*
*
* @author María Aguado (REPORT)
* @author Daniel Calderón (LIST)
* @author Rafael Guzmán (MOVE IN)
*/
    public Status MySolveProblem() {
        // Analizar objetivo
        //System.out.print(A.toString());
        //Info(this.easyPrintPerceptions(E, A));
        CurrentGoal = E.getCurrentGoal();
        
        Info("The goal is " + CurrentGoal);
        
        if (E.getCurrentMission().isOver()) {
            Info("The problem is over");
            this.Message("The problem " + problem + " has been solved");
            return Status.CLOSEPROBLEM;
        }
        
       
        
        if(CurrentGoal.startsWith("MOVEIN"))
        {
            String[] splitGoal = CurrentGoal.split(" ");
            cityGoal = splitGoal[1];
            if(getEnvironment().getCurrentCity().equals(cityGoal))
             {
                 Info("Resolved goal : " + CurrentGoal);
                 E.setNextGoal();
                 return Status.SOLVEPROBLEM;
             }
            
            outbox = session.createReply();
            resetAutoNAV();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);
            
            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            
            return Status.MOVECITY;
            
        }
        
        else if(CurrentGoal.startsWith("LIST"))
        {
            String[] splitGoal = CurrentGoal.split(" ");
            doQueryPeople(splitGoal[1], true);
            Info("Resolved goal : " + CurrentGoal);
            E.setNextGoal();
            return Status.SOLVEPROBLEM;
        }
        
        else if(CurrentGoal.startsWith("REPORT"))
        {

            String[] splitGoal = CurrentGoal.split(" ");
            doSendReport(splitGoal[1]);
            E.setNextGoal();
            return Status.SOLVEPROBLEM;
        }
        
        
        else if(CurrentGoal.startsWith("CAPTURE"))
        {
            String[] splitGoal = CurrentGoal.split(" ");
            cityGoal = splitGoal[3];
            
            //If we have arrived to the city we keep on with the capture
            if(getEnvironment().getCurrentCity().equals(cityGoal))
             {
                 Info("We are in city: " + E.getCurrentCity());
                 doAskBackup(splitGoal[2], Integer.parseInt(splitGoal[1]) );
                 E.setNextGoal();
                 return Status.SOLVEPROBLEM;
             }
            
            outbox = session.createReply();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);
            
            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            
            return Status.MOVECITY;
            
        }
        
        else if(CurrentGoal.startsWith("MOVEBY"))
        {
            String[] splitGoal = CurrentGoal.split(" ");
            
            //If we have arrived to the city we keep on with the capture
            
            String transponder = doAskTransponder(splitGoal[1]);
    
            String[] splitTransponder = transponder.split("/");
            Info("Localizacion1 "+splitTransponder[3]);
            String DESTLocation = (splitTransponder[3].split(" "))[2];
            Info("Locaclizacion2 "+DESTLocation);
            cityGoal = DESTLocation;
            if(getEnvironment().getCurrentCity().equals(cityGoal))
             {
                 Info("Resolved goal : " + CurrentGoal);
                 E.setNextGoal();
                 return Status.SOLVEPROBLEM;
             }
            
            
            
            outbox = session.createReply();
            outbox.setContent("Request course in " + cityGoal + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);
            
            this.LARVAsend(outbox);
            session = this.LARVAblockingReceive();
            E.setExternalPerceptions(session.getContent());

            
            
            
            return Status.MOVECITY;
            
        }
        else if(CurrentGoal.startsWith("TRANSFER"))
        {
            String[] splitGoal = CurrentGoal.split(" ");
            doTransfer();
            Info("Resolved goal : " + CurrentGoal);
            E.setNextGoal();
            return Status.SOLVEPROBLEM;
            
        }
        return Status.CLOSEPROBLEM;
    }
    
    
    /** CREATE REPORT
*
*
* @author María Aguado
* 
* Crea el mensaje a partir de la información almacenada en el diccionario local, 
* dejándolo vacío
* 
*/
    public String doCreateReport(){
        String msg="REPORT;";
        for (Map.Entry<String, Map<String, String>> entry : reports.entrySet()){
            String city = entry.getKey();
            msg += city + " ";
            msg += entry.getValue().entrySet()
                     .stream()
                     .map(e -> e.getKey().toUpperCase()+" "+e.getValue())
                     .collect(joining(" "));
            msg += ";";
        }
        reports.clear();
        return msg;
    }
    
    
    
/** ADD REPORT
*
*
* @author María Aguado
* 
* Incluye la información obtenida en un LIST al diccionario local
*/    
     protected void addReport(String type, String num){
        if (!reports.containsKey(getEnvironment().getCurrentCity())){
            reports.put(getEnvironment().getCurrentCity(), new HashMap<String, String>());
        }
        Map<String, String> currentcitymap = reports.get(getEnvironment().getCurrentCity());
        currentcitymap.put(type, num);
    }
    
     
   /** SEND REPORT
*
*
* @author María Aguado
* 
* Busca un agente del tipo solicitado, crea el mensaje y se lo manda
*/  
   public Status doSendReport(String type){
        Info("Looking for agents: "+ type);
        
        //DroidShip.Debug();

        ArrayList<String> receiver_list = this.DFGetAllProvidersOf("TYPE " + type.toUpperCase());
        int i =0;
        String receiver = receiver_list.get(i);
        
        while(!this.DFHasService(receiver, sessionKey)){
            i++;
            receiver = receiver_list.get(i);
        }
        
        Info("Found agent of type " +type+ ": "+ receiver);
        String report = doCreateReport();
        
        outbox = new ACLMessage();
        outbox.setSender(getAID());
        outbox.addReceiver(new AID(receiver, AID.ISLOCALNAME));
        outbox.setContent(report);
        outbox.setPerformative(ACLMessage.INFORM_REF);
        outbox.setConversationId(sessionKey);
        outbox.setProtocol("DROIDSHIP");
        this.LARVAsend(outbox);
        
        Info("Report sent: " + report + " to " + receiver);
        
        droidDEST = LARVAblockingReceive();
        Info(receiver + " says: " + droidDEST.getContent());
        
        
        return myStatus;
       
   }
    
   
   /** SOLVE GOAL
*
*
* @author Rafael Guzmán
* @author Daniel Calderón
*/
    public Status MyMoveCity()
    {   int altura=E.getGround()/5;
        Info("altura= "+altura);
        if(E.getEnergy()<energybound){
            int contador = 0;
            for(int i=0; i<altura; i++){
                if (contador >= 5){
                    contador = 0;
                    this.MyExecuteAction("RIGHT");
                    this.MyExecuteAction("LEFT");
                    
                }
                this.MyExecuteAction("DOWN");
                contador+=1;
            }
        this.MyReadPerceptions();
        AskForRecharge();
        }
        behaviour = AgPlan(E, A);
        if (behaviour == null || behaviour.isEmpty()) {
            
            String[] splitGoal = CurrentGoal.split(" ");
            Info("Current city : " + this.getEnvironment().getCurrentCity() + " Target city : " + cityGoal);
            if(getEnvironment().getCurrentCity().equals(cityGoal))
            {
                Info("Resolved goal : " + CurrentGoal);
                E.setNextGoal();
                return Status.SOLVEPROBLEM;
                
            }else{
                Alert("Found no plan to execute");
                return Status.CLOSEPROBLEM;
            }

        } else {// Execute
            Info("Found plan: " + behaviour.toString());
            while (!behaviour.isEmpty()) {
                a = behaviour.get(0);
                behaviour.remove(0);
                Info("Excuting " + a);
                if (a.getName().equals("RECHARGE")){
                    AskForRecharge();
                }
                else{
                    this.MyExecuteAction(a.getName());
                /*Info("\n---------------------------------------------------\n"
                        + "executing:" + a.getName() + " :\n " + this.easyPrintPerceptions(E, A)
                        + "\nPlan: " + behaviour.toString() + "\n");*/
                }
                
                if (!Ve(E)) {
                    this.Error("The agent is not alive: " + E.getStatus());
                    return Status.CLOSEPROBLEM;
                }
            }
            this.MyReadPerceptions();
            return Status.MOVECITY;
        }     
    }
    

    public Status MyCloseProblem() {
        outbox = open.createReply();
        outbox.setContent("Cancel session " + sessionKey);
        outbox.setPerformative(ACLMessage.CANCEL);
        outbox.setConversationId(sessionKey);
        Info("Closing problem "+ problem+ ", session " + sessionKey);
        this.LARVAsend(outbox);
        inbox = LARVAblockingReceive();
        Info(problemManager + " says: " + inbox.getContent());
        this.doDestroyNPC();

        return Status.CHECKOUT;
    }
    
    
    public Status MyJoinSession() {
        Info("Querying CITIES");
        outbox = new ACLMessage();
        outbox.setSender(this.getAID());
        outbox.addReceiver(new AID(sessionManager,AID.ISLOCALNAME));
        outbox.setContent("Query cities session " + sessionKey);
        outbox.setPerformative(ACLMessage.QUERY_REF);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = LARVAblockingReceive();
        this.getEnvironment().setExternalPerceptions(session.getContent());
        String[] ciudades = this.getEnvironment().getCityList();
        
        String ciudadElegida = this.inputSelect("Please choose a city", ciudades, "");
        Point3D posCiudad = this.getEnvironment().getCityPosition(ciudadElegida);
        
        this.resetAutoNAV();
        // Register in the DF
        this.DFAddMyServices(new String[]{"TYPE TS"});
        outbox = session.createReply();
        
        //outbox.setContent("Request join session " + sessionKey + " at " + posCiudad.getXInt() + " " + posCiudad.getYInt());
        outbox.setContent("Request join session " + sessionKey + " in " + ciudadElegida);
        outbox.setPerformative(ACLMessage.REQUEST);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = this.LARVAblockingReceive();
        
        if (!session.getContent().startsWith("Confirm")) {
            Error("Could not join session " + sessionKey + " due to " + session.getContent());
            return Status.CLOSEPROBLEM;
        }
        
        this.doPrepareNPC(1, DEST.class);
        this.doPrepareNPC(2, BB1F.class);
        //this.doPrepareNPC(1, YV.class);
        this.doPrepareNPC(1, MTT.class);
        
        
        
        outbox = session.createReply();
        outbox.setContent("Query missions session " + sessionKey);
        outbox.setPerformative(ACLMessage.QUERY_REF);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = this.LARVAblockingReceive();
        this.getEnvironment().setExternalPerceptions(session.getContent());
        
        
        // Immediately afterwards, read the first perceptions
        this.MyReadPerceptions();
        


        
        return SelectMission();
    }
    
    protected Plan AgPlan(Environment E, DecisionSet A) {
        Plan result;
        Ei = E.clone();
        Plan p = new Plan();
        for (int i = 0; i < Ei.getRange() / 2 - 2; i++) {
            Ei.cache();
            Info("\n====================================================\n"
                    + "Planning STEP:" + i + " :\n " + this.easyPrintPerceptions(Ei, A)
                    + "\nPlan: " + p.toString() + "\n");
            if (!Ve(Ei)) {
                return null;
            } else if (G(Ei)) {
                return p;
            } else {
                a = Ag(Ei, A);
                if (a != null) {
                    p.add(a);
                    Ef = S(Ei, a);
                    Ei = Ef;
                } else {
                    return null;
                }
            }
        }
        return p;
    }
    
    
    public boolean MyExecuteAction(String action) {
        Info("Executing action " + action);
        outbox = session.createReply();
        // Remember to include sessionID in all communications
        outbox.setContent("Request execute " + action + " session " + sessionKey);
        outbox.setPerformative(ACLMessage.REQUEST);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = this.LARVAblockingReceive();
        if (!session.getContent().startsWith("Inform")) {
            Error("Unable to execute action " + action + " due to " + session.getContent());
            return false;
        }
        return true;
    }

    public boolean MyReadPerceptions() {
        Info("Reading perceptions");
        outbox = session.createReply();
        outbox.setContent("Query sensors session " + sessionKey);
        outbox.setPerformative(ACLMessage.QUERY_REF);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = this.LARVAblockingReceive();
        if (session.getContent().startsWith("Failure")) {
            Error("Unable to read perceptions due to " + session.getContent());
            return false;
        }
        this.getEnvironment().setExternalPerceptions(session.getContent());
        //Info(this.easyPrintPerceptions());
        return true;
    }
    
    
    public Status SelectMission(){
        String m = chooseMission();
        if(m == null){
            return Status.CLOSEPROBLEM;
        }
        this.getEnvironment().setCurrentMission(m);
        Info("new mission " + m );
        return Status.SOLVEPROBLEM;
    };
    
    protected String chooseMission(){
        Info("Choosing a mission");
        String m = "";
        if(getEnvironment().getAllMissions().length == 1){
            m = this.getEnvironment().getAllMissions()[0];
        }
        else{
            m = this.inputSelect("Please choose a mission", this.getEnvironment().getAllMissions(), "");
        }
        Info(" Selected mission " + m);
        return m;
    }
    
   
        /** DOQUERYPEOPLE
*
*
* @author María Aguado
* @author Daniel Calderón
* 
*/
    public Status doQueryPeople(String type, boolean report) {
        Info("Querying people " +type);
        outbox = session.createReply();
        outbox.setContent("Query " + type.toUpperCase() + " session " + sessionKey);
        outbox.setPerformative(ACLMessage.QUERY_REF);
        outbox.setConversationId(sessionKey);
        this.LARVAsend(outbox);
        session = LARVAblockingReceive();
        
        
        E.setExternalPerceptions(session.getContent());
        if (report){
            //We keep the results in the report map
            this.addReport(type, Integer.toString(E.getPeople().length));
            Info("Report updated: " + reports.toString());
            Message("Found "+ this.getEnvironment().getPeople().length + " " + type + " in " +
                       this.getEnvironment().getCurrentCity());
        }
        return myStatus;
    }
    
    
    
    
    protected String printValue(int v) {
        if (v == Perceptor.NULLREAD) {
            return "XXX ";
        } else {
            return String.format("%03d ", v);
        }
    }

    protected String printValue(double v) {
        if (v == Perceptor.NULLREAD) {
            return "XXX ";
        } else {
            return String.format("%05.2f ", v);
        }
    }
    
    
        /** U
*
*
* @author María Aguado
* 
* Introducimos también la opción de rodear por el otro lado
* 
*/
    @Override
    protected double U(Environment E, Choice a) {
        if (E.getDistance() > 0
                //&& E.getGPS().getZ() < E.getMaxlevel()) {
                && E.getGPS().getZ() < Math.min(E.getVisualFront() + 15, E.getMaxlevel())) {
            return goTakeOff(E, a);
        } 
        //Si estamos por debajo del umbral
        else if (E.getGround() == 0 && E.getEnergy()<20){
            return goRecharge(E,a);
        }
        else if ((E.getDistance() == 0 && E.getGround() > 0) || E.getEnergy()<20) {
            return goLanding(E, a);
        } else if (whichWall.equals("LEFT")) {
            return goFollowWallLeft(E, a);
        }  else if (whichWall.equals("RIGHT")) {
            return goFollowWallRight(E, a);
        } else if (!E.isFreeFront()) {
            return goAvoid(E, a);
        } else {
            return goAhead(E, a);
        }
    }
    
    
    /** GO RECHARGE
*
*
* @author María Aguado
*/
    public double goRecharge(Environment E, Choice a){
        if (a.getName().equals("RECHARGE")) {
            Info("Se recarga energia");
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
    }
    
    // Move up to the flying level
    public double goTakeOff(Environment E, Choice a) {
        if (a.getName().equals("UP")) {
            //return E.getGround()+5;
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
        //return E.getGround()+5;
    }

    // Go down towards the ground level
    public double goLanding(Environment E, Choice a) {
        if (a.getName().equals("DOWN")) {
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
    }

    protected double goAhead(Environment E, Choice a) {
        if (a.getName().equals("MOVE")) {
            
            return U(S(E, a));
        } else if (a.getName().equals("LEFT") || a.getName().equals("RIGHT")) {
            
            return U(S(E, a), new Choice("MOVE"));
        }
        return Choice.MAX_UTILITY;

    }
    
    
    /** U
*
*
* @author María Aguado
* @author Daniel Calderón
* @author Rafael Guzmán
* @author Carlos García
* 
* Introducimos también la opción de rodear por el otro lado
* 
*/
    public double goAvoid(Environment E, Choice a) {
        
        if (E.isTargetFrontLeft() || E.isTargetLeft()) {
            if (a.getName().equals("LEFT")) {
            nextWhichwall = "RIGHT";
            nextdistance = E.getDistance();
            nextPoint=E.getGPS();
            return Choice.ANY_VALUE;
            }
        }   else if (E.isTargetFrontRight() || E.isTargetRight()){
            if (a.getName().equals("RIGHT")) {
            nextWhichwall = "LEFT";
            nextdistance = E.getDistance();
            nextPoint=E.getGPS();
            return Choice.ANY_VALUE;
        }
        }
        
        return Choice.MAX_UTILITY;
    }
    
    
    public void resetAutoNAV() {
//        nextWhichwall = "NONE";
//        nextdistance =   Choice.MAX_UTILITY;
//        nextPoint=null;
        nextWhichwall = whichWall = "NONE";
        nextdistance = distance = Choice.MAX_UTILITY;
        nextPoint=point=null;
    }
    
    @Override
    protected Choice Ag(Environment E, DecisionSet A) {
        if (G(E)) {
            return null;
        } else if (A.isEmpty()) {
            return null;
        } else {
            A = Prioritize(E, A);
            whichWall = nextWhichwall;
            distance = nextdistance;
            point=nextPoint;
            return A.BestChoice();
        }
    }
    
    
    public double goKeepOnWall(Environment E, Choice a) {
        if (a.getName().equals("MOVE")) {
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
    }

    public double goTurnOnWallLeft(Environment E, Choice a) {
        if (a.getName().equals("LEFT")) {
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;

    }
    
    
    
    /**
*
*
* @author María Aguado
* 
* Introducimos también la opción de rodear por el otro lado
* 
*/
    public double goTurnOnWallRight(Environment E, Choice a) {
        if (a.getName().equals("RIGHT")) {
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;

    }

    public double goRevolveWallLeft(Environment E, Choice a) {
        if (a.getName().equals("RIGHT")) {
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
    }
    
    
    
    /**
*
*
* @author María Aguado
* 
* Introducimos también la opción de rodear por el otro lado
* 
*/
    public double goRevolveWallRight(Environment E, Choice a) {
        if (a.getName().equals("LEFT")) {
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
    }

    public double goStopWallLeft(Environment E, Choice a) {
        if (a.getName().equals("RIGHT")) {
            this.resetAutoNAV();
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
    }
    
    
    
    /**
*
*
* @author María Aguado
* 
* Introducimos también la opción de rodear por el otro lado
* 
*/
    public double goStopWallRight(Environment E, Choice a) {
        if (a.getName().equals("LEFT")) {
            this.resetAutoNAV();
            
            return Choice.ANY_VALUE;
        }
        return Choice.MAX_UTILITY;
    }

    public double goFollowWallLeft(Environment E, Choice a) {
        if (E.isFreeFrontLeft()) {
            return goTurnOnWallLeft(E, a);
        } else if (E.isTargetFrontRight()
                && E.isFreeFrontRight()
                && //E.getDistance() < distance
                    E.getDistance() < point.planeDistanceTo(E.getTarget())
                ) {
            return goStopWallLeft(E, a);
        } else if (E.isFreeFront()) {
            return goKeepOnWall(E, a);
        } else {
            return goRevolveWallLeft(E, a);
        }
    }
    
    
    /**
*
*
* @author María Aguado
* 
* Introducimos también la opción de rodear por el otro lado
* 
*/
    public double goFollowWallRight(Environment E, Choice a) {
        if (E.isFreeFrontRight()) {
            return goTurnOnWallRight(E, a);
        } else if (E.isTargetFrontLeft()
                && E.isFreeFrontLeft()
                && //E.getDistance() < distance
                    E.getDistance() < point.planeDistanceTo(E.getTarget())
                ) {
            return goStopWallRight(E, a);
        } else if (E.isFreeFront()) {
            return goKeepOnWall(E, a);
        } else {
            return goRevolveWallRight(E, a);
        }
    }
    
    
        @Override
    public ACLMessage LARVAblockingReceive(){
        boolean exit = false;
        ACLMessage res = null;
        while (!exit){
            res = super.LARVAblockingReceive();
            if (res.getContent().equals("TRANSPONDER") && res.getPerformative()==ACLMessage.QUERY_REF){
                outbox = res.createReply();
                outbox.setPerformative(ACLMessage.INFORM);
                outbox.setContent(this.Transponder());
                LARVAsend(outbox);
            }
            else{
                exit=true;
            }
        }
        return res;
    }
    
    /** ASK FOR RECHARGE
*
*
* @author María Aguado
*/
    public void AskForRecharge(){
        Info("Looking for agents: BB1F");
        
        //DroidShip.Debug();

        ArrayList<String> receiver_list = this.DFGetAllProvidersOf("TYPE BB1F");
        int i =0;
        String receiver = receiver_list.get(i);
        boolean recharge = false;
        while (!recharge){
            
            
        
            do {

                //We look for the next one in the list we already have
                while(!this.DFHasService(receiver, sessionKey)){
                    i++;
                    //If we finished the list, we start again
                    if (i%receiver_list.size()==0){
                        Info("Looking for providers again....");
                        receiver_list = this.DFGetAllProvidersOf("TYPE BB1F");

                    }
                    receiver = receiver_list.get(i%receiver_list.size());
                }

                Info("Found agent BB1F: "+ receiver);

                outbox = new ACLMessage();
                outbox.setSender(getAID());
                outbox.setReplyWith("bb1f_msg"+Integer.toString(i));
                outbox.addReceiver(new AID(receiver, AID.ISLOCALNAME));
                outbox.setContent("REFILL");
                outbox.setPerformative(ACLMessage.REQUEST);
                outbox.setConversationId(sessionKey);
                outbox.setProtocol("DROIDSHIP");
                this.LARVAsend(outbox);

                Info("REQUEST REFILL sent: to " + receiver);
                //If the message is refuse, we try again, else, we continue with the recharge
                droidBB1F = LARVAblockingReceive();
                Info(receiver + " says: " + droidBB1F.getContent());

                content = droidBB1F.getContent();
                contentTokens = content.split(" ");
                
                //If the droidship accepts, it sends a request for transponder, and then an agree message
            }while(droidBB1F.getPerformative()!=ACLMessage.AGREE);
        
        Info("Request refilled accepted by droidship "+ receiver);
        
        //droidship is going to send us two transponder requests, so we just wait until the inform message
        droidBB1F = LARVAblockingReceive();
        Info(receiver + " says: " + droidBB1F.getContent());
        content = droidBB1F.getContent();
        contentTokens = content.split(" ");
        if (!contentTokens[0].toUpperCase().equals("FAILURE")){
            Info("Recharge completed, current energy level: "+E.getEnergy());
            recharge = true;
        }
        //If there has been a failure in some of the messages, the process starts all over again
        
        }
        
        
    }
    
    
    /** GO RECHARGE
*
*
* @author María Aguado
* @author Daniel Calderón
*/
    public void doAskBackup(String type, int n){
        Info("Looking for agents: MTT");
        
        //DroidShip.Debug();

        ArrayList<String> receiver_list = this.DFGetAllProvidersOf("TYPE MTT");
        int i =0;
        String receiver = receiver_list.get(i);
        boolean backup = false;
        while (!backup){
            
            
        
            do {

                //We look for the next one in the list we already have
                while(!this.DFHasService(receiver, sessionKey)){
                    i++;
                    //If we finished the list, we start again
                    if (i%receiver_list.size()==0){
                        Info("Looking for providers again....");
                        receiver_list = this.DFGetAllProvidersOf("TYPE MTT");


                    }
                    receiver = receiver_list.get(i%receiver_list.size());
                }

                Info("Found agent BB1F: "+ receiver);

                outbox = new ACLMessage();
                outbox.setSender(getAID());
                outbox.setReplyWith("mtt_msg"+Integer.toString(i));
                outbox.addReceiver(new AID(receiver, AID.ISLOCALNAME));
                Info("Receiver" + receiver);
                outbox.setContent("BACKUP");
                outbox.setPerformative(ACLMessage.REQUEST);
                outbox.setConversationId(sessionKey);
                outbox.setProtocol("DROIDSHIP");
                this.LARVAsend(outbox);

                Info("REQUEST BACKUP sent: to " + receiver);
                //If the message is refuse, we try again, else, we continue with the recharge
                droidMTT = LARVAblockingReceive();
                Info(receiver + " says: " + droidMTT.getContent());

                content = droidMTT.getContent();
                contentTokens = content.split(" ");
                
                //If the droidship accepts, it sends a request for transponder, and then an agree message
            }while(droidMTT.getPerformative()!=ACLMessage.AGREE);
        
        Info("Request backup accepted by droidship "+ receiver);
        
        //droidship is going to send us two transponder requests, so we just wait until the inform message
        droidMTT = LARVAblockingReceive();
        Info(receiver + " says: " + droidMTT.getContent());
        content = droidMTT.getContent();
        contentTokens = content.split(" ");
        if (!contentTokens[0].toUpperCase().equals("FAILURE")){
            Info("MTT is coming to the city");
            backup = true;
        }
        //If there has been a failure in some of the messages, the process starts all over again
        
        }
        doCapture(type, n);

        //Liberamos al mtt
        outbox = new ACLMessage();
        outbox.setSender(getAID());
        outbox.setReplyWith("mtt_msg"+Integer.toString(i));
        outbox.addReceiver(new AID(receiver, AID.ISLOCALNAME));
        outbox.setContent("CANCEL");
        outbox.setPerformative(ACLMessage.CANCEL);
        outbox.setConversationId(sessionKey);
        outbox.setProtocol("DROIDSHIP");
        this.LARVAsend(outbox);

       // droidMTT = LARVAblockingReceive();
        //Info(receiver + " says: " + droidMTT.getContent());
    
        
    }
    
    
    public void doCapture(String type, int n){
        //Se encarga de pedirle al session manager que capture 
        doQueryPeople(type, false);
        String[] names = E.getPeople();
        for (int i =0;  i < n; i ++){
            outbox = session.createReply();
            outbox.setContent("Request capture " + names[i] + " session " + sessionKey);
            outbox.setPerformative(ACLMessage.REQUEST);
            outbox.setConversationId(sessionKey);
            outbox.setReplyWith("capture_"+Integer.toString(i));
            
            this.LARVAsend(outbox);

            session = LARVAblockingReceive();
            
            
            if (session.getPerformative()==ACLMessage.FAILURE) {
                Info("Capture "+ names[i]+ "failed: " + session.getContent());
            }
            else{
                Info("Capture "+ names[i]+ "correct ");
                capturedPeople.add(names[i]);
            }
        }
        Info("Finished capturing people");
    }
    
    public String doAskTransponder(String noreceiver){
        Info("Looking for agents: DEST");
        
        //DroidShip.Debug();

          ArrayList<String> receiver_list = this.DFGetAllProvidersOf("TYPE DEST");
        int i =0;
        String receiver = receiver_list.get(i);
        
       
        //We look for the next one in the list we already have
        while (!this.DFHasService(receiver, sessionKey)) {
            i++;
            //If we finished the list, we start again
            if (i % receiver_list.size() == 0) {
                Info("Looking for providers again....");
                receiver_list = this.DFGetAllProvidersOf("TYPE DEST");

            }
            receiver = receiver_list.get(i % receiver_list.size());
        }
        
        DESTship = receiver; 

        Info("Found agent DEST: " + receiver);

                outbox = new ACLMessage();
                outbox.setSender(getAID());
                outbox.setReplyWith("dest_msg");
                outbox.addReceiver(new AID(receiver, AID.ISLOCALNAME));
                outbox.setContent("TRANSPONDER");
                outbox.setPerformative(ACLMessage.QUERY_REF);
                outbox.setConversationId(sessionKey);
                outbox.setProtocol("DROIDSHIP");
                this.LARVAsend(outbox);

                
                droidDEST = LARVAblockingReceive();
                Info(receiver + " says: " + droidDEST.getContent());

                content = droidDEST.getContent();
                Info("Content doasktransponder = " + content);
                return content;
                
             
    }
    
    public void doTransfer(){
        
        int n=capturedPeople.size();
        
        for (int i =0;  i < n; i ++)
        {
            
                outbox = droidDEST.createReply();
                outbox.setContent("TRANSFER " + capturedPeople.get(i));
                outbox.setPerformative(ACLMessage.REQUEST);
                outbox.setConversationId(sessionKey);
                outbox.setProtocol("DROIDSHIP");
                this.LARVAsend(outbox);
            
          
                droidDEST = LARVAblockingReceive();
                
                if (droidDEST.getPerformative()==ACLMessage.FAILURE) {
                Info("Transfer " + "failed: " + droidDEST.getContent());
            }
            else{
                Info("Transfer " + "correct "); 
            }    
        }
        
        Info("Finished transfering people");

    }
    
    
    
    
    
    public String easyPrintPerceptions(Environment E, DecisionSet A) {
        if (showPerceptions == false){
            return "";
        }
        String res;
        int matrix[][];

        if (getEnvironment() == null) {
            Error("Environment is unacessible, please setupEnvironment() first");
            return "";
        }
        res = "\n\nReading of sensors\n";
        if (E.getName() == null) {
            res += emojis.WARNING + " UNKNOWN AGENT";
            return res;
        } else {
            res += emojis.ROBOT + " " + E.getName();
        }
        res += "\n";
        res += String.format("%10s: %05d W\n", "ENERGY", E.getEnergy());
        res += String.format("%10s: %15s\n", "POSITION", E.getGPS().toString());
//        res += "PAYLOAD "+E.getPayload()+" m"+"\n";
        res += String.format("%10s: %05d m\n", "X", E.getGPS().getXInt())
                + String.format("%10s: %05d m\n", "Y", E.getGPS().getYInt())
                + String.format("%10s: %05d m\n", "Z", E.getGPS().getZInt())
                + String.format("%10s: %05d m\n", "MAXLEVEL", E.getMaxlevel())
                + String.format("%10s: %05d m\n", "MAXSLOPE", E.getMaxslope());
        res += String.format("%10s: %05d m\n", "GROUND", E.getGround());
        res += String.format("%10s: %05d º\n", "COMPASS", E.getCompass());
        if (E.getTarget() == null) {
            res += String.format("%10s: " + "!", "TARGET");
        } else {
            res += String.format("%10s: %05.2f m\n", "DISTANCE", E.getDistance());
            res += String.format("%10s: %05.2f º\n", "ABS ALPHA", E.getAngular());
            res += String.format("%10s: %05.2f º\n", "REL ALPHA", E.getRelativeAngular());
        }
        res += "\nVISUAL RELATIVE\n";
        matrix = E.getRelativeVisual();
        for (int y = 0; y < matrix[0].length; y++) {
            for (int x = 0; x < matrix.length; x++) {
                res += printValue(matrix[x][y]);
            }
            res += "\n";
        }
        for (int x = 0; x < matrix.length; x++) {
            if (x != matrix.length / 2) {
                res += "----";
            } else {
                res += "[  ]-";
            }
        }
        res += "LIDAR RELATIVE\n";
        matrix = E.getRelativeLidar();
        for (int y = 0; y < matrix[0].length; y++) {
            for (int x = 0; x < matrix.length; x++) {
                res += printValue(matrix[x][y]);
            }
            res += "\n";
        }
        for (int x = 0; x < matrix.length; x++) {
            if (x != matrix.length / 2) {
                res += "----";
            } else {
                res += "-^^-";
            }
        }
        res += "\n";
        res += "Decision Set: " + A.toString() + "\n";
        return res;
    }
    
    
    
    
    // A new method just to show the information of sensors in console
    public String easyPrintPerceptions() {
        if (showPerceptions == false){
            return "";
        }
        String res;
        int matrix[][];
        if (!logger.isEcho()) {
            return "";
        }
        if (getEnvironment() == null) {
            Error("Environment is unacessible, please setupEnvironment() first");
            return "";
        }
        if (!showPerceptions) {
            return "";
        }
        res = "\n\nReading of sensors\n";
        if (getEnvironment().getName() == null) {
            res += emojis.WARNING + " UNKNOWN AGENT";
            return res;
        } else {
            res += emojis.ROBOT + " " + this.getEnvironment().getName();
        }
        res += "\n";
        res += String.format("%10s: %05d W %05d W %05d W\n", "ENERGY",
                this.getEnvironment().getEnergy(), this.getEnvironment().getEnergyburnt(), myEnergy);
        res += String.format("%10s: %15s\n", "POSITION", this.getEnvironment().getGPS().toString());
//        res += "PAYLOAD "+getEnvironment().getPayload()+" m"+"\n";
        res += String.format("%10s: %05d m\n", "X", this.getEnvironment().getGPS().getXInt())
                + String.format("%10s: %05d m\n", "Y", this.getEnvironment().getGPS().getYInt())
                + String.format("%10s: %05d m\n", "Z", this.getEnvironment().getGPS().getZInt())
                + String.format("%10s: %05d m\n", "MAXLEVEL", this.getEnvironment().getMaxlevel())
                + String.format("%10s: %05d m\n", "MAXSLOPE", this.getEnvironment().getMaxslope());
        res += String.format("%10s: %05d m\n", "GROUND", this.getEnvironment().getGround());
        res += String.format("%10s: %05d º\n", "COMPASS", this.getEnvironment().getCompass());
        if (getEnvironment().getTarget() == null) {
            res += String.format("%10s: " + "!", "TARGET");
        } else {
            res += String.format("%10s: %05.2f m\n", "DISTANCE", this.getEnvironment().getDistance());
            res += String.format("%10s: %05.2f º\n", "ABS ALPHA", this.getEnvironment().getAngular());
            res += String.format("%10s: %05.2f º\n", "REL ALPHA", this.getEnvironment().getRelativeAngular());
        }
//        res += "\nVISUAL ABSOLUTE\n";
//        matrix = this.getEnvironment().getAbsoluteVisual();
//        for (int y = 0; y < matrix[0].length; y++) {
//            for (int x = 0; x < matrix.length; x++) {
//                res += printValue(matrix[x][y]);
//            }
//            res += "\n";
//        }
//        for (int x = 0; x < matrix.length; x++) {
//            if (x != matrix.length / 2) {
//                res += "----";
//            } else {
//                res += "[  ]-";
//            }
//        }
        res += "\nVISUAL RELATIVE\n";
        matrix = this.getEnvironment().getRelativeVisual();
        for (int y = 0; y < matrix[0].length; y++) {
            for (int x = 0; x < matrix.length; x++) {
                res += printValue(matrix[x][y]);
            }
            res += "\n";
        }
        for (int x = 0; x < matrix.length; x++) {
            if (x != matrix.length / 2) {
                res += "----";
            } else {
                res += "[  ]-";
            }
        }
//        res += "VISUAL POLAR\n";
//        matrix = this.getEnvironment().getPolarVisual();
//        for (int y = 0; y < matrix[0].length; y++) {
//            for (int x = 0; x < matrix.length; x++) {
//                res += printValue(matrix[x][y]);
//            }
//            res += "\n";
//        }
//        res += "\n";
        res += "LIDAR RELATIVE\n";
        matrix = this.getEnvironment().getRelativeLidar();
        for (int y = 0; y < matrix[0].length; y++) {
            for (int x = 0; x < matrix.length; x++) {
                res += printValue(matrix[x][y]);
            }
            res += "\n";
        }
        for (int x = 0; x < matrix.length; x++) {
            if (x != matrix.length / 2) {
                res += "----";
            } else {
                res += "-^^-";
            }
        }
        res += "\n";
        res += this.Prioritize(E, A).toString();
        res += "\nWall:\n" + whichWall + "\n";
        return res;
    }
    // The execution on any agent might be seen as a finite state automaton
    // whose states are these
    enum Status {
        START, // Begin execution
        CHECKIN, // Send passport to Identity Manager
        OPENPROBLEM, // ASks Problem Manager to open an instance of a problem
        SOLVEPROBLEM, // Really do this!
        CLOSEPROBLEM,
        MOVECITY,// After that, ask Problem Manager to close the problem
        CHECKOUT, // ASk Identity Manager to leave out
        EXIT,
        SELECTMISSION,
        JOINSESSION
    }

    

}
